const state = {
  users: [],
  customers: [],
  deliveries: [],
  bbm: [],
  files: [],
}

export default state